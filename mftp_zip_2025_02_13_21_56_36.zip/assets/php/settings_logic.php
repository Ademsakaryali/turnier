<?php
session_start();
require_once __DIR__ . '/../../includes/db_connect.php';
require_once __DIR__ . '/settings/shared_functions.php';

// Überprüfe, ob der Benutzer eingeloggt und Administrator oder Koordinator ist
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['Administrator', 'Koordinator'])) {
    header("Location: login.php");
    exit();
}

$userEmail = $_SESSION['email'] ?? 'Benutzer';
$userRole = $_SESSION['role'] ?? 'Unbekannte Rolle';

// Entfernen Sie die getAllUsers() und getAllRoles() Funktionen von hier,
// da sie jetzt in shared_functions.php definiert sind

