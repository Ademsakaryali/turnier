<?php
// Start the session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);

// Get user role
$userRole = $_SESSION['role'] ?? '';

// Define sidebar menu items
$menuItems = [
    ['title' => 'Dashboard', 'icon' => 'fas fa-home', 'url' => 'admin_dashboard', 'roles' => ['Administrator', 'Koordinator']],
    ['title' => 'Teams', 'icon' => 'fas fa-users', 'url' => 'all_teams', 'roles' => ['Administrator', 'Koordinator', 'Trainer']],
    ['title' => 'Spieler', 'icon' => 'fas fa-running', 'url' => 'all_players', 'roles' => ['Administrator', 'Koordinator', 'Trainer']],
    ['title' => 'Einstellungen', 'icon' => 'fas fa-cog', 'url' => 'settings', 'roles' => ['Administrator']],
];

// Filter menu items based on user role
$filteredMenuItems = array_filter($menuItems, function($item) use ($userRole) {
    return in_array($userRole, $item['roles']);
});

// Get current page for active state
$currentPage = basename($_SERVER['PHP_SELF'], '.php');

