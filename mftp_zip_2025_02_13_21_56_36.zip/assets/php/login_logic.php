<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';

    if (!empty($email) && !empty($password)) {
        try {
            // Check if the roles table exists
            $check_roles_table = $pdo->query("SHOW TABLES LIKE 'roles'");
            if ($check_roles_table->rowCount() == 0) {
                throw new Exception("Die Datenbanktabellen wurden nicht korrekt eingerichtet. Bitte führen Sie zuerst das Setup-Skript aus.");
            }

            $stmt = $pdo->prepare("
                SELECT u.id, u.email, u.password, r.role 
                FROM users u
                LEFT JOIN user_roles ur ON u.id = ur.user_id
                LEFT JOIN roles r ON ur.role_id = r.id
                WHERE u.email = :email
                LIMIT 1
            ");
            
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'] ?? 'User'; // Fallback role if none assigned

                // Update last login timestamp
                $update_stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = :id");
                $update_stmt->execute([':id' => $user['id']]);

                if ($user['role'] == 'Administrator' || $user['role'] == 'Koordinator') {
                    header("Location: admin_dashboard.php");
                } else {
                    header("Location: index.php");
                }
                exit();
            } else {
                $error_message = "Ungültige E-Mail oder Passwort.";
            }
        } catch (PDOException $e) {
            $error_message = "Datenbankfehler: Bitte kontaktieren Sie den Administrator.";
            error_log("Database Error: " . $e->getMessage());
        } catch (Exception $e) {
            $error_message = $e->getMessage();
        }
    } else {
        $error_message = "Bitte füllen Sie alle Felder aus.";
    }
}

