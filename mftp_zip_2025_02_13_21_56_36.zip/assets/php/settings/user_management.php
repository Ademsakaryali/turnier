<?php
require_once __DIR__ . '/shared_functions.php';

function getUsersByType($type) {
    $roleMap = [
        'admin' => 'Administrator',
        'manager' => 'Teammanager',
        'player' => 'Spieler'
    ];
    
    $role = $roleMap[$type] ?? 'Administrator';
    
    try {
        return fetchAll("SELECT u.id, u.email, u.firstname, u.lastname, u.is_active, r.role 
                        FROM users u 
                        LEFT JOIN user_roles ur ON u.id = ur.user_id 
                        LEFT JOIN roles r ON ur.role_id = r.id 
                        WHERE r.role = :role", 
                        [':role' => $role]);
    } catch (Exception $e) {
        error_log("Error fetching users by type: " . $e->getMessage());
        return [];
    }
}

function searchUsers($query, $type) {
    $roleMap = [
        'admin' => 'Administrator',
        'manager' => 'Teammanager',
        'player' => 'Spieler'
    ];
    
    $role = $roleMap[$type] ?? 'Administrator';
    
    try {
        return fetchAll("SELECT u.id, u.email, u.firstname, u.lastname, u.is_active, r.role 
                        FROM users u 
                        LEFT JOIN user_roles ur ON u.id = ur.user_id 
                        LEFT JOIN roles r ON ur.role_id = r.id 
                        WHERE r.role = :role 
                        AND (u.email LIKE :query 
                             OR u.firstname LIKE :query 
                             OR u.lastname LIKE :query)", 
                        [
                            ':role' => $role,
                            ':query' => "%$query%"
                        ]);
    } catch (Exception $e) {
        error_log("Error searching users: " . $e->getMessage());
        return [];
    }
}

$type = $_GET['type'] ?? 'admin';
$users = getUsersByType($type);
$roles = getAllRoles();

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $response = ['success' => false, 'message' => ''];

    try {
        switch ($_POST['action']) {
            case 'search':
                $query = $_POST['query'] ?? '';
                $type = $_POST['type'] ?? 'admin';
                $users = searchUsers($query, $type);
                $response = ['success' => true, 'users' => $users];
                break;

            case 'create':
            case 'update':
                $userId = $_POST['id'] ?? null;
                $data = [
                    'email' => $_POST['email'],
                    'firstname' => $_POST['firstname'],
                    'lastname' => $_POST['lastname'],
                    'role_id' => $_POST['role'],
                    'is_active' => isset($_POST['is_active']) ? 1 : 0
                ];

                if ($_POST['password']) {
                    $data['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
                }

                if ($userId) {
                    // Update existing user
                    $stmt = $pdo->prepare("UPDATE users SET email = :email, firstname = :firstname, 
                                         lastname = :lastname, is_active = :is_active 
                                         " . (isset($data['password']) ? ", password = :password" : "") . "
                                         WHERE id = :id");
                    $params = $data;
                    $params['id'] = $userId;
                    $stmt->execute($params);

                    // Update role
                    $stmt = $pdo->prepare("UPDATE user_roles SET role_id = :role_id WHERE user_id = :user_id");
                    $stmt->execute(['role_id' => $data['role_id'], 'user_id' => $userId]);
                } else {
                    // Create new user
                    if (!isset($data['password'])) {
                        throw new Exception("Passwort ist erforderlich für neue Benutzer");
                    }

                    $stmt = $pdo->prepare("INSERT INTO users (email, firstname, lastname, password, is_active) 
                                         VALUES (:email, :firstname, :lastname, :password, :is_active)");
                    $stmt->execute($data);
                    $userId = $pdo->lastInsertId();

                    // Insert role
                    $stmt = $pdo->prepare("INSERT INTO user_roles (user_id, role_id) VALUES (:user_id, :role_id)");
                    $stmt->execute(['user_id' => $userId, 'role_id' => $data['role_id']]);
                }

                $response = ['success' => true, 'message' => 'Benutzer erfolgreich gespeichert'];
                break;

            case 'delete':
                $userId = $_POST['id'] ?? null;
                if ($userId) {
                    $stmt = $pdo->prepare("DELETE FROM users WHERE id = :id");
                    $stmt->execute(['id' => $userId]);
                    $response = ['success' => true, 'message' => 'Benutzer erfolgreich gelöscht'];
                }
                break;
        }
    } catch (Exception $e) {
        $response = ['success' => false, 'message' => $e->getMessage()];
        error_log("User management error: " . $e->getMessage());
    }

    echo json_encode($response);
    exit;
}

