<?php
require_once __DIR__ . '/../../../includes/db_connect.php';

function getAllUsers() {
    try {
        return fetchAll("SELECT u.id, u.email, u.is_active, r.role 
                         FROM users u 
                         LEFT JOIN user_roles ur ON u.id = ur.user_id 
                         LEFT JOIN roles r ON ur.role_id = r.id");
    } catch (Exception $e) {
        error_log("Error fetching users: " . $e->getMessage());
        return [];
    }
}

function getAllRoles() {
    try {
        return fetchAll("SELECT * FROM roles");
    } catch (Exception $e) {
        error_log("Error fetching roles: " . $e->getMessage());
        return [];
    }
}

// Fügen Sie hier weitere gemeinsam genutzte Funktionen hinzu

