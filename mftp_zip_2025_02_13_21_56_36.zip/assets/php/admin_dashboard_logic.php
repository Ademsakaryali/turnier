<?php
session_start();
require_once 'includes/db_connect.php';

// Überprüfe, ob der Benutzer eingeloggt und Administrator oder Koordinator ist
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['Administrator', 'Koordinator'])) {
    header("Location: login");
    exit();
}

// Hole Statistiken aus der Datenbank
function getDashboardStats() {
    try {
        return [
            'teams' => fetchOne("SELECT COUNT(*) as count FROM teams")['count'] ?? 0,
            'players' => fetchOne("SELECT COUNT(*) as count FROM players")['count'] ?? 0,
            'users' => fetchOne("SELECT COUNT(*) as count FROM users")['count'] ?? 0,
            'active_players' => fetchOne("SELECT COUNT(*) as count FROM players WHERE is_active = 1")['count'] ?? 0
        ];
    } catch (Exception $e) {
        error_log("Dashboard Error: " . $e->getMessage());
        return ['teams' => 0, 'players' => 0, 'users' => 0, 'active_players' => 0];
    }
}

$stats = getDashboardStats();
$userEmail = $_SESSION['email'] ?? 'Benutzer';
$userRole = $_SESSION['role'] ?? 'Unbekannte Rolle';

