// Import Bootstrap (assuming it's included via a CDN or similar)
// If not using a CDN, you'll need to adjust this import based on your project setup.
// For example: import * as bootstrap from './path/to/bootstrap.bundle.min.js';

document.addEventListener("DOMContentLoaded", () => {
  const userModal = new bootstrap.Modal(document.getElementById("userModal"))
  const deleteModal = new bootstrap.Modal(document.getElementById("deleteModal"))
  const userForm = document.getElementById("userForm")
  const userTableBody = document.getElementById("userTableBody")
  const searchInput = document.getElementById("userSearch")
  let currentUserId = null

  // Benutzer hinzufügen/bearbeiten
  document.getElementById("addUserBtn").addEventListener("click", () => openUserModal())
  document.getElementById("saveUser").addEventListener("click", saveUser)

  // Benutzer löschen
  document.getElementById("confirmDelete").addEventListener("click", deleteUser)

  // Bearbeiten-Button-Ereignis delegieren
  if (userTableBody) {
    userTableBody.addEventListener("click", (e) => {
      if (e.target.closest(".edit-user")) {
        const userId = e.target.closest(".edit-user").dataset.id
        openUserModal(userId)
      } else if (e.target.closest(".delete-user")) {
        currentUserId = e.target.closest(".delete-user").dataset.id
        deleteModal.show()
      }
    })
  }

  // Echtzeit-Suche
  if (searchInput) {
    searchInput.addEventListener("input", debounce(searchUsers, 300))
  }

  function openUserModal(userId = null) {
    currentUserId = userId
    if (userForm) userForm.reset()
    if (userId) {
      // Benutzer bearbeiten
      const row = document.querySelector(`[data-id="${userId}"]`).closest("tr")
      document.getElementById("userModalLabel").textContent = "Benutzer bearbeiten"
      document.getElementById("firstname").value = row.cells[0].textContent
      document.getElementById("lastname").value = row.cells[1].textContent
      document.getElementById("email").value = row.cells[2].textContent
      document.getElementById("role").value = row.cells[3].textContent
      document.getElementById("is_active").checked = row.cells[4].textContent.trim() === "Aktiv"
      document.getElementById("password").required = false
    } else {
      // Neuen Benutzer hinzufügen
      document.getElementById("userModalLabel").textContent = "Benutzer hinzufügen"
      document.getElementById("password").required = true
    }
    userModal.show()
  }

  function saveUser() {
    if (!userForm || !userForm.checkValidity()) {
      userForm.reportValidity()
      return
    }

    const formData = new FormData(userForm)
    formData.append("action", currentUserId ? "update" : "create")
    if (currentUserId) formData.append("id", currentUserId)

    fetch("assets/php/settings/user_management.php", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          userModal.hide()
          refreshUserList()
        } else {
          alert(data.message || "Ein Fehler ist aufgetreten")
        }
      })
      .catch((error) => console.error("Error:", error))
  }

  function deleteUser() {
    if (!currentUserId) return

    fetch("assets/php/settings/user_management.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: `action=delete&id=${currentUserId}`,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          deleteModal.hide()
          refreshUserList()
        } else {
          alert(data.message || "Ein Fehler ist aufgetreten")
        }
      })
      .catch((error) => console.error("Error:", error))
  }

  function searchUsers() {
    const query = searchInput.value.trim()
    const type = new URLSearchParams(window.location.search).get("type") || "admin"

    fetch("assets/php/settings/user_management.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: `action=search&query=${encodeURIComponent(query)}&type=${type}`,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          updateUserTable(data.users)
        }
      })
      .catch((error) => console.error("Error:", error))
  }

  function refreshUserList() {
    const type = new URLSearchParams(window.location.search).get("type") || "admin"
    fetch(`assets/php/settings/user_management.php?type=${type}`)
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          updateUserTable(data.users)
        }
      })
      .catch((error) => console.error("Error:", error))
  }

  function updateUserTable(users) {
    if (!userTableBody) return
    userTableBody.innerHTML = ""
    users.forEach((user) => {
      const row = document.createElement("tr")
      row.innerHTML = `
                <td>${escapeHtml(user.firstname)}</td>
                <td>${escapeHtml(user.lastname)}</td>
                <td>${escapeHtml(user.email)}</td>
                <td>${escapeHtml(user.role)}</td>
                <td>
                    <span class="status-badge ${user.is_active ? "active" : "inactive"}">
                        ${user.is_active ? "Aktiv" : "Inaktiv"}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-primary edit-user" data-id="${user.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-sm btn-danger delete-user" data-id="${user.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `
      userTableBody.appendChild(row)
    })
  }

  function escapeHtml(unsafe) {
    return unsafe
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;")
  }

  function debounce(func, wait) {
    let timeout
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout)
        func(...args)
      }
      clearTimeout(timeout)
      timeout = setTimeout(later, wait)
    }
  }

  // Initial load
  refreshUserList()
})

