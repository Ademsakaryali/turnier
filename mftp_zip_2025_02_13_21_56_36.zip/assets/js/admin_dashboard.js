document.addEventListener("DOMContentLoaded", () => {
  // Sidebar Toggle Funktionalität
  const sidebarToggle = document.getElementById("sidebar-toggle")
  const sidebar = document.querySelector(".sidebar")
  const mainContent = document.querySelector(".main-content")

  if (sidebarToggle) {
    sidebarToggle.addEventListener("click", () => {
      sidebar.classList.toggle("active")
    })
  }

  // Klick außerhalb der Sidebar schließt diese auf mobilen Geräten
  document.addEventListener("click", (e) => {
    if (window.innerWidth <= 768) {
      if (!sidebar.contains(e.target) && !sidebarToggle.contains(e.target)) {
        sidebar.classList.remove("active")
      }
    }
  })

  // Statistik-Karten Animation
  const statCards = document.querySelectorAll(".stat-card")
  statCards.forEach((card) => {
    card.addEventListener("mouseenter", () => {
      card.style.transform = "translateY(-5px)"
    })

    card.addEventListener("mouseleave", () => {
      card.style.transform = "translateY(0)"
    })
  })

  // Aktuelle Seite in der Navigation hervorheben
  const currentPath = window.location.pathname
  const navLinks = document.querySelectorAll(".sidebar-nav a")

  navLinks.forEach((link) => {
    if (link.getAttribute("href") === currentPath.split("/").pop()) {
      link.classList.add("active")
    }
  })

  // Responsive Design Anpassungen
  function handleResize() {
    if (window.innerWidth > 768) {
      sidebar.classList.remove("active")
      mainContent.style.marginLeft = ""
    }
  }

  window.addEventListener("resize", handleResize)
})

// Optional: Smooth Scroll für iOS
document.documentElement.style.scrollBehavior = "smooth"

