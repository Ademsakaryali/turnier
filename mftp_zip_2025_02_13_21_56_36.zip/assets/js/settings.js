document.addEventListener("DOMContentLoaded", () => {
  // Navigation functionality
  const navLinks = document.querySelectorAll(".settings-nav .nav-link")
  const sections = document.querySelectorAll(".settings-sections section")

  navLinks.forEach((link) => {
    link.addEventListener("click", function () {
      const target = this.getAttribute("data-target")

      navLinks.forEach((l) => l.classList.remove("active"))
      this.classList.add("active")

      sections.forEach((section) => {
        section.classList.remove("active")
        if (section.id === target) {
          section.classList.add("active")
        }
      })
    })
  })

  // Sidebar toggle functionality
  const sidebarToggle = document.getElementById("sidebar-toggle")
  const sidebar = document.querySelector(".sidebar")

  if (sidebarToggle) {
    sidebarToggle.addEventListener("click", () => {
      sidebar.classList.toggle("active")
    })
  }

  // Collapsible sidebar functionality
  const navGroups = document.querySelectorAll(".nav-group-header")
  navGroups.forEach((group) => {
    group.addEventListener("click", () => {
      const content = group.nextElementSibling
      const icon = group.querySelector(".fa-chevron-down")

      content.classList.toggle("show")
      icon.style.transform = content.classList.contains("show") ? "rotate(180deg)" : "rotate(0)"
    })
  })
})

