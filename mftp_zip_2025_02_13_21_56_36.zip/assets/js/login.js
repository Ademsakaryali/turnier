document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm")
  const emailInput = document.getElementById("email")
  const passwordInput = document.getElementById("password")
  const togglePasswordButton = document.getElementById("togglePassword")

  loginForm.addEventListener("submit", (e) => {
    const email = emailInput.value.trim()
    const password = passwordInput.value.trim()

    if (email === "" || password === "") {
      e.preventDefault()
      showError("Bitte füllen Sie alle Felder aus.")
    } else if (!isValidEmail(email)) {
      e.preventDefault()
      showError("Bitte geben Sie eine gültige E-Mail-Adresse ein.")
    }
  })

  togglePasswordButton.addEventListener("click", () => {
    const type = passwordInput.getAttribute("type") === "password" ? "text" : "password"
    passwordInput.setAttribute("type", type)
    togglePasswordButton.querySelector("i").classList.toggle("fa-eye")
    togglePasswordButton.querySelector("i").classList.toggle("fa-eye-slash")
  })

  function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return re.test(email)
  }

  function showError(message) {
    const errorDiv = document.createElement("div")
    errorDiv.className = "alert alert-danger"
    errorDiv.innerHTML = `<i class="fas fa-exclamation-circle me-2"></i>${message}`
    loginForm.insertBefore(errorDiv, loginForm.firstChild)

    setTimeout(() => {
      errorDiv.remove()
    }, 5000)
  }
})

