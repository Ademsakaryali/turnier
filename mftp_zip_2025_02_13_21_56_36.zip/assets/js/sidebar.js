document.addEventListener("DOMContentLoaded", () => {
  const sidebar = document.querySelector(".sidebar")
  const sidebarToggle = document.getElementById("sidebar-toggle")
  const hamburgerMenu = document.querySelector(".hamburger-menu")
  const navLinks = document.querySelectorAll(".sidebar-nav a")
  const currentPath = window.location.pathname
  const mainContent = document.querySelector(".main-content")

  function toggleSidebar() {
    if (window.innerWidth <= 768) {
      sidebar.classList.toggle("active")
      hamburgerMenu.classList.toggle("active")
      document.body.classList.toggle("sidebar-open")
    } else {
      sidebar.classList.toggle("collapsed")
      if (sidebar.classList.contains("collapsed")) {
        mainContent.style.marginLeft = "60px"
      } else {
        mainContent.style.marginLeft = "250px"
      }
    }
  }

  // Sidebar toggle functionality
  if (sidebarToggle) {
    sidebarToggle.addEventListener("click", toggleSidebar)
  }

  // Hamburger menu functionality
  if (hamburgerMenu) {
    hamburgerMenu.addEventListener("click", toggleSidebar)
  }

  // Close sidebar when clicking outside on mobile
  document.addEventListener("click", (e) => {
    if (window.innerWidth <= 768 && sidebar.classList.contains("active")) {
      if (!sidebar.contains(e.target) && !hamburgerMenu.contains(e.target)) {
        toggleSidebar()
      }
    }
  })

  // Highlight active nav item
  navLinks.forEach((link) => {
    if (link.getAttribute("href") === currentPath) {
      link.classList.add("active")
    }
  })

  // Responsive behavior
  function handleResize() {
    if (window.innerWidth > 768) {
      sidebar.classList.remove("active")
      hamburgerMenu.classList.remove("active")
      document.body.classList.remove("sidebar-open")
      if (sidebar.classList.contains("collapsed")) {
        mainContent.style.marginLeft = "60px"
      } else {
        mainContent.style.marginLeft = "250px"
      }
    } else {
      mainContent.style.marginLeft = "0"
    }
  }

  window.addEventListener("resize", handleResize)
  handleResize() // Call once to set initial state
})

