<?php
// Datenbankverbindungsdetails
$host = 'mysqlsvr84.world4you.com';  // Normalerweise 'localhost', es sei denn, Ihr Hosting-Provider gibt etwas anderes an
$db   = '4417071db9';  // Der Name Ihrer Datenbank
$user = 'sql6013963';  // Ihr Datenbank-Benutzername
$pass = 'gkr+er74';  // Ihr Datenbank-Passwort
$charset = 'utf8mb4';  // Empfohlen für volle Unicode-Unterstützung

// DSN (Data Source Name) für PDO
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

// PDO-Optionen für bessere Fehlerbehandlung und Leistung
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,  // Werfen von Ausnahmen bei Fehlern
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,        // Standardmäßig assoziative Arrays zurückgeben
    PDO::ATTR_EMULATE_PREPARES   => false,                   // Echte vorbereitete Anweisungen verwenden
];

try {
    // Erstellen einer neuen PDO-Instanz
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // Im Falle eines Verbindungsfehlers
    // Hinweis: In einer Produktionsumgebung sollten Sie keine detaillierten Fehlermeldungen anzeigen
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Funktion zum sicheren Ausführen von Abfragen
function executeQuery($sql, $params = []) {
    global $pdo;
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    } catch (\PDOException $e) {
        // Fehlerprotokollierung
        error_log("Database Error: " . $e->getMessage());
        // Allgemeine Fehlermeldung zurückgeben
        throw new \Exception("Ein Datenbankfehler ist aufgetreten. Bitte versuchen Sie es später erneut.");
    }
}

// Funktion zum Abrufen eines einzelnen Datensatzes
function fetchOne($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetch();
}

// Funktion zum Abrufen mehrerer Datensätze
function fetchAll($sql, $params = []) {
    $stmt = executeQuery($sql, $params);
    return $stmt->fetchAll();
}

