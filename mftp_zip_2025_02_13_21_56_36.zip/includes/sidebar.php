<?php
require_once 'assets/php/sidebar_logic.php';
?>
<link rel="stylesheet" href="assets/css/sidebar.css">
<div class="hamburger-menu">
    <span></span>
    <span></span>
    <span></span>
</div>
<div class="sidebar">
    <div class="sidebar-header">
        <i class="fas fa-futbol"></i>
        <span>Admin Panel</span>
    </div>
    <nav class="sidebar-nav">
        <?php foreach ($filteredMenuItems as $item): ?>
            <a href="<?php echo $item['url']; ?>.php" <?php echo ($currentPage == $item['url']) ? 'class="active"' : ''; ?>>
                <i class="<?php echo $item['icon']; ?>"></i>
                <span><?php echo $item['title']; ?></span>
            </a>
        <?php endforeach; ?>
        <?php if ($isLoggedIn): ?>
            <a href="logout.php" class="logout-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Abmelden</span>
            </a>
        <?php endif; ?>
    </nav>
</div>
<script src="assets/js/sidebar.js"></script>

