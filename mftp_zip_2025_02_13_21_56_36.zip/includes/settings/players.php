<?php require_once 'assets/php/settings/players.php'; ?>

<h2>Spieler-Einstellungen</h2>
<!-- Add player settings content here -->

