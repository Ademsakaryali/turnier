<?php require_once 'assets/php/settings/general_settings.php'; ?>

<h2>Allgemeine Einstellungen</h2>
<!-- Add general settings content here -->

