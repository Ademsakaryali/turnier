<?php require_once 'assets/php/settings/team_managers.php'; ?>

<h2>Teammanager-Einstellungen</h2>
<!-- Add team manager settings content here -->

