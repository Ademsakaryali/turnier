<?php require_once 'assets/php/settings/roles.php'; ?>

<h2>Rollen-Einstellungen</h2>
<!-- Add role settings content here -->

