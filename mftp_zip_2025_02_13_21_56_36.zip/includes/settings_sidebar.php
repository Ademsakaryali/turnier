<?php
$settingsPages = [
    [
        'title' => 'Benutzerverwaltung',
        'icon' => 'fas fa-users-cog',
        'children' => [
            ['title' => 'Administratoren', 'url' => 'settings.php?type=admin', 'icon' => 'fas fa-user-shield'],
            ['title' => 'Teammanager', 'url' => 'settings.php?type=manager', 'icon' => 'fas fa-user-tie'],
            ['title' => 'Spieler', 'url' => 'settings.php?type=player', 'icon' => 'fas fa-running'],
        ]
    ],
    ['title' => 'Rollen', 'url' => 'settings.php?page=roles', 'icon' => 'fas fa-user-tag'],
    ['title' => 'Allgemeine Einstellungen', 'url' => 'settings.php?page=general', 'icon' => 'fas fa-cogs'],
];

$currentPage = $_GET['page'] ?? 'users';
$currentType = $_GET['type'] ?? 'admin';
?>

<div class="settings-sidebar">
    <nav>
        <?php foreach ($settingsPages as $page): ?>
            <?php if (isset($page['children'])): ?>
                <div class="nav-group">
                    <div class="nav-group-header" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo sanitize_title($page['title']); ?>">
                        <i class="<?php echo $page['icon']; ?>"></i>
                        <span><?php echo $page['title']; ?></span>
                        <i class="fas fa-chevron-down ms-auto"></i>
                    </div>
                    <div class="collapse nav-group-content" id="collapse-<?php echo sanitize_title($page['title']); ?>">
                        <?php foreach ($page['children'] as $child): ?>
                            <a href="<?php echo $child['url']; ?>" 
                               class="<?php echo ($currentType === basename($child['url'], '.php')) ? 'active' : ''; ?>">
                                <i class="<?php echo $child['icon']; ?>"></i>
                                <span><?php echo $child['title']; ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php else: ?>
                <a href="<?php echo $page['url']; ?>" 
                   class="<?php echo ($currentPage === basename($page['url'], '.php')) ? 'active' : ''; ?>">
                    <i class="<?php echo $page['icon']; ?>"></i>
                    <span><?php echo $page['title']; ?></span>
                </a>
            <?php endif; ?>
        <?php endforeach; ?>
    </nav>
</div>

<?php
function sanitize_title($title) {
    return strtolower(preg_replace('/[^a-zA-Z0-9]/', '-', $title));
}
?>

